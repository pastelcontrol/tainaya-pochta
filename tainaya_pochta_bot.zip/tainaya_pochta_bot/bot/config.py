import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass
class Config:
    token: str
    group_id: int
    admins: set[int]
    db_path: str
    reserve_hours: int

def load_config():
    token = os.getenv("BOT_TOKEN", "").strip()
    group_id = int(os.getenv("GROUP_ID", "0"))
    admins = {int(x.strip()) for x in os.getenv("ADMIN_IDS", "").split(",") if x.strip()}
    if not token or token == "PASTE_TOKEN_HERE":
        raise RuntimeError("Заполните BOT_TOKEN в .env")
    if not group_id:
        raise RuntimeError("Заполните GROUP_ID в .env")
    if not admins:
        raise RuntimeError("Укажите ADMIN_IDS в .env")
    return Config(token, group_id, admins,
                  os.getenv("DATABASE_PATH", "data/tainaya_pochta.sqlite3"),
                  max(1, int(os.getenv("RESERVATION_HOURS", "48"))))
