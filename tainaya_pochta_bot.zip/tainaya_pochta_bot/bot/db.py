import aiosqlite
from pathlib import Path
from datetime import datetime, timezone, timedelta

def now():
    return datetime.now(timezone.utc).isoformat()

class DB:
    def __init__(self, path):
        self.path = path

    async def conn(self):
        Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        db = await aiosqlite.connect(self.path)
        db.row_factory = aiosqlite.Row
        await db.execute("PRAGMA foreign_keys=ON")
        return db

    async def init(self):
        async with await self.conn() as db:
            await db.executescript('''
            CREATE TABLE IF NOT EXISTS users(
              tg_id INTEGER PRIMARY KEY, username TEXT DEFAULT '', display_name TEXT NOT NULL,
              city TEXT DEFAULT '', carrier TEXT DEFAULT '', pickup_point TEXT DEFAULT '',
              favorites TEXT DEFAULT '', materials TEXT DEFAULT '', characters TEXT DEFAULT '',
              wishes TEXT DEFAULT '', dislikes TEXT DEFAULT '', about TEXT DEFAULT '',
              active INTEGER DEFAULT 1, created_at TEXT NOT NULL, updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS shipments(
              id INTEGER PRIMARY KEY AUTOINCREMENT, sender_id INTEGER NOT NULL, recipient_id INTEGER NOT NULL,
              anonymous INTEGER DEFAULT 0, status TEXT NOT NULL, carrier TEXT DEFAULT '',
              tracking TEXT DEFAULT '', note TEXT DEFAULT '', reserved_until TEXT DEFAULT '',
              sent_at TEXT DEFAULT '', received_at TEXT DEFAULT '', created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
              FOREIGN KEY(sender_id) REFERENCES users(tg_id), FOREIGN KEY(recipient_id) REFERENCES users(tg_id)
            );
            CREATE INDEX IF NOT EXISTS shipment_status_idx ON shipments(status);
            ''')
            await db.commit()

    async def touch_user(self, uid, username, name):
        async with await self.conn() as db:
            await db.execute('''INSERT INTO users(tg_id,username,display_name,created_at,updated_at)
              VALUES(?,?,?,?,?) ON CONFLICT(tg_id) DO UPDATE SET username=excluded.username,
              display_name=CASE WHEN users.display_name='' THEN excluded.display_name ELSE users.display_name END,
              updated_at=excluded.updated_at''', (uid, username or "", name or "Участник", now(), now()))
            await db.commit()

    async def user(self, uid):
        async with await self.conn() as db:
            cur = await db.execute("SELECT * FROM users WHERE tg_id=? AND active=1", (uid,))
            return await cur.fetchone()

    async def save_profile(self, uid, vals):
        keys = ["display_name","city","carrier","pickup_point","favorites","materials","characters","wishes","dislikes","about"]
        async with await self.conn() as db:
            await db.execute("UPDATE users SET " + ",".join(k+"=?" for k in keys) + ",updated_at=? WHERE tg_id=?",
                             tuple(vals.get(k, "") for k in keys) + (now(), uid))
            await db.commit()

    async def catalog(self, uid):
        async with await self.conn() as db:
            cur = await db.execute('''
            SELECT u.tg_id,u.display_name,u.city,u.favorites,u.materials,u.characters,u.wishes,u.dislikes,
              (SELECT COUNT(*) FROM shipments s WHERE s.recipient_id=u.tg_id AND s.status='received') got,
              (SELECT MAX(received_at) FROM shipments s WHERE s.recipient_id=u.tg_id AND s.status='received') last_got
            FROM users u WHERE u.active=1 AND u.tg_id<>? AND u.pickup_point<>''
            AND NOT EXISTS(SELECT 1 FROM shipments x WHERE x.sender_id=? AND x.recipient_id=u.tg_id
              AND x.status IN ('reserved','sent','in_transit','arrived'))
            AND NOT EXISTS(SELECT 1 FROM shipments x WHERE x.recipient_id=u.tg_id AND x.status='reserved'
              AND x.reserved_until>?)
            ORDER BY got ASC, CASE WHEN last_got IS NULL THEN 0 ELSE 1 END ASC,
              last_got ASC, u.created_at ASC
            ''', (uid, uid, now()))
            return await cur.fetchall()

    async def reserve(self, sender, recipient, hours):
        until = (datetime.now(timezone.utc) + timedelta(hours=hours)).isoformat()
        async with await self.conn() as db:
            await db.execute("UPDATE shipments SET status='expired',updated_at=? WHERE status='reserved' AND reserved_until<?", (now(), now()))
            cur = await db.execute("SELECT id FROM shipments WHERE recipient_id=? AND status='reserved' AND reserved_until>?", (recipient, now()))
            if await cur.fetchone():
                return None
            cur = await db.execute("SELECT id FROM shipments WHERE sender_id=? AND recipient_id=? AND status IN ('reserved','sent','in_transit','arrived')", (sender, recipient))
            if await cur.fetchone():
                return None
            cur = await db.execute("SELECT tg_id FROM users WHERE tg_id=? AND active=1 AND pickup_point<>''", (recipient,))
            if not await cur.fetchone():
                return None
            cur = await db.execute("INSERT INTO shipments(sender_id,recipient_id,status,reserved_until,created_at,updated_at) VALUES(?,?,'reserved',?,?,?)",
                                   (sender, recipient, until, now(), now()))
            await db.commit()
            return cur.lastrowid

    async def shipment(self, sid):
        async with await self.conn() as db:
            cur = await db.execute('''SELECT s.*,r.display_name recipient_name,r.city recipient_city,
              r.carrier recipient_carrier,r.pickup_point recipient_pickup,r.tg_id recipient_tg,
              a.display_name sender_name,a.tg_id sender_tg
              FROM shipments s JOIN users r ON r.tg_id=s.recipient_id
              JOIN users a ON a.tg_id=s.sender_id WHERE s.id=?''', (sid,))
            return await cur.fetchone()

    async def update_shipment(self, sid, **fields):
        fields["updated_at"] = now()
        async with await self.conn() as db:
            await db.execute("UPDATE shipments SET " + ",".join(k+"=?" for k in fields) + " WHERE id=?",
                             tuple(fields.values()) + (sid,))
            await db.commit()

    async def history(self, uid, sent):
        col, other = ("sender_id","recipient_id") if sent else ("recipient_id","sender_id")
        async with await self.conn() as db:
            cur = await db.execute(f'''SELECT s.*,u.display_name other_name FROM shipments s
              JOIN users u ON u.tg_id=s.{other} WHERE s.{col}=? ORDER BY s.created_at DESC LIMIT 30''', (uid,))
            return await cur.fetchall()

    async def stats(self):
        async with await self.conn() as db:
            cur = await db.execute('''SELECT
              (SELECT COUNT(*) FROM users WHERE active=1) users,
              (SELECT COUNT(*) FROM shipments WHERE status IN ('sent','in_transit','arrived','received')) sent,
              (SELECT COUNT(*) FROM shipments WHERE status='received') received,
              (SELECT COUNT(*) FROM shipments WHERE status IN ('sent','in_transit','arrived')) transit,
              (SELECT COUNT(*) FROM users u WHERE active=1 AND NOT EXISTS
                (SELECT 1 FROM shipments s WHERE s.recipient_id=u.tg_id AND s.status='received')) no_gifts''')
            return await cur.fetchone()

    async def admin_shipments(self):
        async with await self.conn() as db:
            cur = await db.execute('''SELECT s.*,a.display_name sender_name,r.display_name recipient_name
              FROM shipments s JOIN users a ON a.tg_id=s.sender_id
              JOIN users r ON r.tg_id=s.recipient_id ORDER BY s.created_at DESC LIMIT 25''')
            return await cur.fetchall()

    async def hide_user(self, uid):
        async with await self.conn() as db:
            await db.execute("UPDATE users SET active=0,updated_at=? WHERE tg_id=?", (now(), uid))
            await db.commit()
