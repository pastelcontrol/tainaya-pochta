import asyncio, logging
from datetime import datetime, timezone
from aiogram import Bot, Dispatcher, F
from aiogram.filters import CommandStart, Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup, KeyboardButton
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage
from bot.config import load_config
from bot.db import DB

logging.basicConfig(level=logging.INFO)
cfg = load_config()
db = DB(cfg.db_path)
bot = Bot(cfg.token)
dp = Dispatcher(storage=MemoryStorage())

class Form(StatesGroup):
    name=State(); city=State(); carrier=State(); pickup=State()
    favorites=State(); materials=State(); characters=State(); wishes=State(); dislikes=State(); about=State()
class Parcel(StatesGroup):
    carrier=State(); tracking=State(); note=State()

FIELDS = [
 ("name","Как к вам обращаться? Укажите имя или никнейм."),
 ("city","Ваш город?"),
 ("carrier","Какая служба доставки вам удобна?"),
 ("pickup","Укажите удобный ПВЗ: служба доставки, адрес и/или номер пункта. Не присылайте код получения."),
 ("favorites","Какие раскраски, жанры и сюжеты вы любите?"),
 ("materials","Любимые материалы и бренды?"),
 ("characters","Любимые персонажи, фандомы, художники?"),
 ("wishes","Что вас особенно порадует? О чём мечтаете?"),
 ("dislikes","Что вам точно не подходит?"),
 ("about","Немного о себе и своих увлечениях.")
]
STATES = [Form.name,Form.city,Form.carrier,Form.pickup,Form.favorites,Form.materials,Form.characters,Form.wishes,Form.dislikes,Form.about]
KEYS = ["display_name","city","carrier","pickup_point","favorites","materials","characters","wishes","dislikes","about"]
MENU = ReplyKeyboardMarkup(keyboard=[
 [KeyboardButton(text="📝 Моя анкета"),KeyboardButton(text="📬 Кому отправить?")],
 [KeyboardButton(text="📦 Мои отправления"),KeyboardButton(text="💌 Мои подарки")],
 [KeyboardButton(text="📋 Общий список"),KeyboardButton(text="📊 Статистика")],
 [KeyboardButton(text="⚙️ Настройки")]], resize_keyboard=True)

def ik(rows):
    return InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text=t,callback_data=d) for t,d in row] for row in rows])

async def member(uid):
    try:
        m=await bot.get_chat_member(cfg.group_id,uid)
        return m.status not in ("left","kicked")
    except Exception:
        return False

async def gate(message):
    if not await member(message.from_user.id):
        await message.answer("Доступ открыт только участникам нашего Telegram-сообщества. Вступите в группу и попробуйте снова 💌")
        return False
    await db.touch_user(message.from_user.id,message.from_user.username,message.from_user.full_name)
    return True

async def gate_call(call):
    if not await member(call.from_user.id):
        await call.answer("Только для участников сообщества",show_alert=True); return False
    await db.touch_user(call.from_user.id,call.from_user.username,call.from_user.full_name)
    return True

def status_label(s):
    return {"reserved":"Зарезервирована","sent":"Отправлена","in_transit":"В пути","arrived":"Прибыла в ПВЗ","received":"Получена","cancelled":"Отменена","expired":"Резерв истёк"}.get(s,s)

async def ask_profile(message,state):
    await state.clear(); await state.set_state(STATES[0])
    await state.update_data(profile={})
    await message.answer("Заполним анкету. На любом шаге можно написать «—», чтобы пропустить поле.\n\n"+FIELDS[0][1])

async def profile_step(message,state,index):
    val=message.text.strip()
    if val=="—": val=""
    data=await state.get_data(); values=data.get("profile",{})
    values[KEYS[index]]=val
    await state.update_data(profile=values)
    if index+1<len(FIELDS):
        await state.set_state(STATES[index+1]); await message.answer(FIELDS[index+1][1])
    else:
        if not values.get("display_name"): values["display_name"]=message.from_user.full_name or "Участник"
        await db.save_profile(message.from_user.id,values)
        await state.clear()
        await message.answer("Анкета сохранена! Вы появились в каталоге 🎁",reply_markup=MENU)

@dp.message(CommandStart())
async def start(m:Message,state:FSMContext):
    if not await gate(m): return
    p=await db.user(m.from_user.id)
    await m.answer("Добро пожаловать в «Тайную почту»! 🦉",reply_markup=MENU)
    if not p or not p["pickup_point"]:
        await ask_profile(m,state)

@dp.message(Command("cancel"))
async def cancel(m:Message,state:FSMContext):
    await state.clear(); await m.answer("Действие отменено.",reply_markup=MENU)

for i,st in enumerate(STATES):
    async def handler(m:Message,state:FSMContext,_i=i):
        await profile_step(m,state,_i)
    dp.message.register(handler,st)

@dp.message(F.text=="📝 Моя анкета")
async def profile(m:Message):
    if not await gate(m): return
    p=await db.user(m.from_user.id)
    if not p or not p["pickup_point"]:
        await m.answer("Анкета ещё не заполнена.")
        return
    await m.answer(f"<b>{p['display_name']}</b>\nГород: {p['city']}\nДоставка: {p['carrier']}\nПВЗ: {p['pickup_point']}\n\nЛюбимые раскраски: {p['favorites']}\nМатериалы: {p['materials']}\nПерсонажи: {p['characters']}\nПожелания: {p['wishes']}\nНе подходит: {p['dislikes']}\nО себе: {p['about']}",
                   reply_markup=ik([[("Изменить анкету ✏️","edit_profile")]]))

@dp.callback_query(F.data=="edit_profile")
async def edit_profile(c:CallbackQuery,state:FSMContext):
    if not await gate_call(c): return
    await ask_profile(c.message,state); await c.answer()

async def show_catalog(m):
    people=await db.catalog(m.from_user.id)
    if not people:
        await m.answer("Пока нет доступных анкет. Загляните позже 💌"); return
    await m.answer("📋 <b>Каталог участников</b>\nСначала идут те, кто ещё не получал подарков. Адреса ПВЗ здесь не показываются.")
    for p in people[:50]:
        got=p["got"]
        label="✨ Ещё не получал(а)" if got==0 else f"🎁 Получено: {got}"
        text=f"<b>{p['display_name']}</b> · {p['city'] or 'город не указан'}\n{label}\nЛюбит: {p['favorites'] or '—'}\nМатериалы: {p['materials'] or '—'}\nПерсонажи: {p['characters'] or '—'}\nПожелания: {p['wishes'] or '—'}\nНе подходит: {p['dislikes'] or '—'}"
        await m.answer(text,reply_markup=ik([[("Хочу порадовать 🎁",f"pick:{p['tg_id']}")]]))

@dp.message(F.text.in_({"📋 Общий список","📬 Кому отправить?"}))
async def catalog(m:Message):
    if await gate(m): await show_catalog(m)

@dp.callback_query(F.data.startswith("pick:"))
async def pick(c:CallbackQuery):
    if not await gate_call(c): return
    rid=int(c.data.split(":")[1])
    if rid==c.from_user.id:
        await c.answer("Нельзя выбрать себя",show_alert=True); return
    sid=await db.reserve(c.from_user.id,rid,cfg.reserve_hours)
    if not sid:
        await c.answer("Участник уже зарезервирован или недоступен. Обновите список.",show_alert=True); return
    s=await db.shipment(sid)
    await c.message.answer(f"Вы выбрали <b>{s['recipient_name']}</b> 🎁\nГород: {s['recipient_city']}\nСлужба доставки: {s['recipient_carrier']}\nПВЗ: {s['recipient_pickup']}\n\nАдрес доступен только вам и администраторам. Резерв действует {cfg.reserve_hours} ч.\nВыберите режим:",
       reply_markup=ik([[("Обычная отправка","mode:%s:0"%sid)],[("Тайная отправка 🕯️","mode:%s:1"%sid)],[("Отменить резерв","release:%s"%sid)]]))
    await c.answer()

@dp.callback_query(F.data.startswith("mode:"))
async def mode(c:CallbackQuery):
    _,sid,anon=c.data.split(":"); sid=int(sid)
    s=await db.shipment(sid)
    if not s or s["sender_id"]!=c.from_user.id or s["status"]!="reserved":
        await c.answer("Резерв не найден",show_alert=True); return
    await db.update_shipment(sid,anonymous=int(anon))
    await c.message.answer("Когда отправите посылку, нажмите кнопку ниже.",
       reply_markup=ik([[("📦 Я отправил(а) посылку",f"sent:{sid}")]]))
    await c.answer("Режим сохранён")

@dp.callback_query(F.data.startswith("release:"))
async def release(c:CallbackQuery):
    sid=int(c.data.split(":")[1]); s=await db.shipment(sid)
    if s and s["sender_id"]==c.from_user.id and s["status"]=="reserved":
        await db.update_shipment(sid,status="cancelled",reserved_until="")
        await c.message.answer("Резерв отменён. Спасибо, что сообщили 💌")
    await c.answer()

@dp.callback_query(F.data.startswith("sent:"))
async def sent(c:CallbackQuery,state:FSMContext):
    sid=int(c.data.split(":")[1]); s=await db.shipment(sid)
    if not s or s["sender_id"]!=c.from_user.id or s["status"]!="reserved":
        await c.answer("Отправление не найдено",show_alert=True); return
    await state.clear(); await state.update_data(sid=sid); await state.set_state(Parcel.carrier)
    await c.message.answer("Какой службой отправили посылку?")
    await c.answer()

@dp.message(Parcel.carrier)
async def parcel_carrier(m:Message,state:FSMContext):
    await state.update_data(carrier=m.text.strip()); await state.set_state(Parcel.tracking)
    await m.answer("Укажите трек-номер или напишите «—».")

@dp.message(Parcel.tracking)
async def parcel_tracking(m:Message,state:FSMContext):
    await state.update_data(tracking="" if m.text.strip()=="—" else m.text.strip())
    await state.set_state(Parcel.note); await m.answer("Добавьте пожелание получателю или напишите «—».")

@dp.message(Parcel.note)
async def parcel_note(m:Message,state:FSMContext):
    data=await state.get_data(); sid=data["sid"]; s=await db.shipment(sid)
    if not s or s["sender_id"]!=m.from_user.id:
        await state.clear(); await m.answer("Отправление не найдено."); return
    await db.update_shipment(sid,status="sent",carrier=data["carrier"],tracking=data["tracking"],
        note="" if m.text.strip()=="—" else m.text.strip(),sent_at=datetime.now(timezone.utc).isoformat(),reserved_until="")
    try:
        await bot.send_message(s["recipient_tg"],"Кажется, к вам летит сова! 🦉 Отправитель сообщил об отправке посылки. Когда она придёт, подтвердите получение в разделе «Мои подарки».")
    except Exception:
        pass
    await state.clear(); await m.answer("Отправление записано! Спасибо за доброту ❤️",reply_markup=MENU)

@dp.message(F.text=="📦 Мои отправления")
async def sent_list(m:Message):
    if not await gate(m): return
    rows=await db.history(m.from_user.id,True)
    if not rows: await m.answer("Вы пока никому не отправляли посылки."); return
    for s in rows:
        await m.answer(f"№{s['id']} · {s['other_name']}\nСтатус: {status_label(s['status'])}\nСлужба: {s['carrier'] or '—'}\nТрек: {s['tracking'] or '—'}")

@dp.message(F.text=="💌 Мои подарки")
async def received_list(m:Message):
    if not await gate(m): return
    rows=await db.history(m.from_user.id,False)
    if not rows: await m.answer("Пока подарков нет. Возможно, сова уже в пути 🦉"); return
    for s in rows:
        txt=f"№{s['id']} · {status_label(s['status'])}"
        if s["status"] in ("sent","in_transit","arrived"):
            txt+=f"\nСлужба: {s['carrier'] or '—'}\nТрек: {s['tracking'] or '—'}"
            await m.answer(txt,reply_markup=ik([[("🎁 Я получила посылку",f"got:{s['id']}")]]))
        else: await m.answer(txt)

@dp.callback_query(F.data.startswith("got:"))
async def got(c:CallbackQuery):
    sid=int(c.data.split(":")[1]); s=await db.shipment(sid)
    if not s or s["recipient_id"]!=c.from_user.id or s["status"] not in ("sent","in_transit","arrived"):
        await c.answer("Нельзя подтвердить это отправление",show_alert=True); return
    await db.update_shipment(sid,status="received",received_at=datetime.now(timezone.utc).isoformat())
    if not s["anonymous"]:
        try: await bot.send_message(s["sender_tg"],f"Ура! 🎁 {s['recipient_name']} подтвердил(а) получение вашей посылки. Спасибо!")
        except Exception: pass
    await c.message.answer("Получение отмечено! Спасибо, что поделились радостью ❤️")
    await c.answer("Спасибо!")

@dp.message(F.text=="📊 Статистика")
async def stats(m:Message):
    if not await gate(m): return
    s=await db.stats()
    await m.answer(f"📊 <b>Тайная почта</b>\nУчастников: {s['users']}\nОтправлено: {s['sent']}\nПолучено: {s['received']}\nВ пути: {s['transit']}\nУчастников без подарков: {s['no_gifts']}")

@dp.message(F.text=="⚙️ Настройки")
async def settings(m:Message):
    if not await gate(m): return
    await m.answer("Настройки анкеты:",reply_markup=ik([[("Изменить анкету ✏️","edit_profile")],[("Скрыть мою анкету","hide_me")]]))

@dp.callback_query(F.data=="hide_me")
async def hide_me(c:CallbackQuery):
    if not await gate_call(c): return
    await db.hide_user(c.from_user.id)
    await c.message.answer("Анкета скрыта из каталога. История отправлений сохранена для корректной статистики.")
    await c.answer()

@dp.message(Command("admin"))
async def admin(m:Message):
    if m.from_user.id not in cfg.admins:
        await m.answer("Нет доступа."); return
    s=await db.stats(); rows=await db.admin_shipments()
    out=f"🛠 <b>Админ-панель</b>\nУчастников: {s['users']}\nОтправлено: {s['sent']}\nПолучено: {s['received']}\nВ пути: {s['transit']}\nБез подарков: {s['no_gifts']}\n\n<b>Последние отправления:</b>\n"
    for x in rows:
        out+=f"№{x['id']} · {x['sender_name']} → {x['recipient_name']} · {status_label(x['status'])}\n"
    await m.answer(out)

async def main():
    await db.init()
    await dp.start_polling(bot)

if __name__=="__main__":
    asyncio.run(main())
